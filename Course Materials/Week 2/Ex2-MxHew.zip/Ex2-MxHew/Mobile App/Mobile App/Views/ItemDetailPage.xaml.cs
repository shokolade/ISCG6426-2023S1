﻿using System.ComponentModel;
using Mobile_App.ViewModels;
using Xamarin.Forms;

namespace Mobile_App.Views
{
    public partial class ItemDetailPage : ContentPage
    {
        public ItemDetailPage()
        {
            InitializeComponent();
            BindingContext = new ItemDetailViewModel();
        }
    }
}
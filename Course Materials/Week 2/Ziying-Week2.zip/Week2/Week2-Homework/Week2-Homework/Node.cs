﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week2_Homework
{
    public class Node
    {
        int value;
        Node next;

        public Node(int value)
        {
            this.value = value;
        }

        public int getValue()
        {
            return value;
        }

        public Node getNext()
        {
            return next;
        }
        public void setNext(Node i)
        {
            next = i;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection;
using System.Runtime.Remoting.Messaging;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Week2_Homework
{
    public class NodeList
    {
        Node head;
        int length = 0;
        Node min;
        Node max;

        public int getLength()
        {
            return length;
        }

        public Node getMax()
        {
            return max;
        }

        public Node getMin()
        {
            return min;
        }

        public override string ToString()
        {
            Node pointer = head;
            String str = "";
            while (pointer != null)
            {
                str += pointer.getValue() + ",";
                pointer = pointer.getNext();
            }
            return str;
        }

        public void addNode(Node item)
        {
            if (head == null)
            {
                head = item;
            } else { 
                Node pointer = head;
                while(pointer.getNext() != null)
                {
                    pointer = pointer.getNext();
                }
                pointer.setNext(item);
            }
            length++;
            if (min == null)
            {
                min = item;
            } else if (min.getValue() > item.getValue())
            {
                min = item;
            }
            if (max == null) {
                max = item;
            } else if (max.getValue() < item.getValue())
            {
                max = item;
            }
        }

    }
}

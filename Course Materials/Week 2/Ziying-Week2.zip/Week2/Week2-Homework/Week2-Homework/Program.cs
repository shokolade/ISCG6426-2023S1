﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week2_Homework
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Declare a NodeList
            NodeList list = new NodeList();
            // Add a node in NodeList
            Node n1 = new Node(7);
            list.addNode(n1);
            // Add a second node
            Node n2 = new Node(2);
            list.addNode(n2);
            // Add a third node
            Node n3 = new Node(1);
            list.addNode(n3);
            Console.WriteLine("length of list is {0}", list.getLength());
            Console.WriteLine("Mininum value of list is {0}", list.getMin().getValue());
            Console.WriteLine("Maximum value of list is {0}", list.getMax().getValue());
            Console.WriteLine( list.ToString());
        }

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week2_Class_Exercise
{
    internal class AppendToArr
    {
        static void Main(string[] args)
        {
            int[] myArr1 = { 1, 2, 3, 4, 5 };

            int[] myArr2 = AppendToArr.AppeToArr(myArr1, 6);

            Console.WriteLine(myArr2.Length);
        }
        public static int[] AppeToArr(int[] arr, int numAppend)
        {
            int[] newArr = new int[arr.Length + 1];
            for (int i = 0; i < arr.Length; i++)
            {
                newArr[i] = arr[i];
            }
            newArr[arr.Length] = numAppend;
            return newArr;
        }
    }

}


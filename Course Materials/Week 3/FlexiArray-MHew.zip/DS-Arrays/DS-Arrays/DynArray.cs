﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DS_Arrays
{
    class DynArray
    {
        private int[] primary;
        public int length = 0;
        private int maxLength;

        public DynArray(int size)
        {
            primary = new int[size];
            maxLength = primary.Length;
        }

        public void append(int item)
        {
            Console.WriteLine(length);
            length++;
            if (length >= maxLength)
            {
                IncreaseSize();
            }
            primary[length] = item;
            
        }

        private void IncreaseSize()
        {
            Console.WriteLine("Expanding....");
            int[] placeholder = new int[maxLength * 2];
            for (int i = 0; i < maxLength; i++)
            {
                placeholder[i] = primary[i];
            }
            primary = placeholder;
            maxLength = primary.Length;
        }

        public void Report()
        {
            Console.WriteLine("REPORT");
            Console.WriteLine("Current Length: " + this.length);
            Console.WriteLine("Maximum Length: " + this.maxLength);
            Console.WriteLine("Latest Item " + this.primary[length]);
        }
    }
}

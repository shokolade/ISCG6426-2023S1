﻿using System;

namespace DS_Arrays
{
    class Program
    {
        
        static void Main(string[] args)
        { 
            int[] myNum = new int[100];
            string[] cars = {"MINI", "BMW", "MG", "Telsa"};
            int[] myNum2 = { 1, 2, 3, 4, 5 };

            myNum2[4] = 100;

            
            //Console.WriteLine(myNum2[4]);

            /*for (int i = 0; i < myNum.Length; i++)
            {
                Console.WriteLine(myNum2[i]);
            }*/

            int[,] matrixA = new int[3,4];
            /*for (int i = 0; i < matrixA.Length; i++)
            {
                Console.WriteLine("");
                for (int j = 0; j < matrixA[i].Length; j++)
                {

                }
            }*/


            DynArray arr = new DynArray(2);
            for(int i = 0; i < 4; i++)
            {
                arr.append(i);
            }

            for (int i = 4; i < 100; i++)
            {
                arr.append(i);
            }

            arr.Report();
        }
    }
}

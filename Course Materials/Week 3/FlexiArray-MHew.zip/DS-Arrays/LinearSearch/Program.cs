﻿using System;

namespace LinearSearch
{
    class Program
    {
        const int ITEMS = 10;
        const int SEARCH_FOR = 5;
        static void Main(string[] args)
        {
            int[] anArr = new int[5] { 1, 2, 5, 3, 4 };
            linearSearch(anArr, SEARCH_FOR);
        }

        public static int[] createRandomArray(int numItems)
        {
            int[] arr = new int[numItems];
            Random rnd = new Random();
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = rnd.Next(10);
            }
            return arr;
        }

        public static void linearSearch(int[] arr, int value)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == value)
                {
                    Console.WriteLine("Value: " + value.ToString() + " has been found at index [" + i + "]");
                    return;
                }
            }
            Console.WriteLine("Could not find value");
        }
    }
}

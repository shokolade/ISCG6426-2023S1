﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlexiArray
{
    /// <summary>
    /// Flexi Array is a flexible type of array where you do not need to declare the size before hand. It grows dynamically
    /// allowing you to add elements without running out of space. As it grows dynamically, based on demand, FlexiArray does
    /// not waste memory by declaring a large array at design time.
    /// This is the Integer variant of the FlexiArray.
    /// </summary>
    internal class FlexiArray
    {
        //Lets declare an array to hold our collection of Values, invisible to outsiders
        private int[] MyStore = new int[10];
        //Lets declare an interger that keeps track of the last index position, where a value was set.
        private int intLastPos = -1;

        /// <summary>
        /// Add method allows you to add elements to the flexible Array. It does not run out of space, as it grows dynamically
        /// </summary>
        /// <param name="Value">An integer value to add</param>
        public void Add(int Value)
        {
            //before adding new value, first check if we have reached the full capacity of the underlying array. Last position
            //would be the length of the array minus 1, as arrays are zero based. Lastpostion 9 means Mystore[9] has been already
            //taken. Mystore[0] to Mystore[9] are the 10 indexes of the 10 elements of the array. If full, creae a new temporary
            //array that is twice as big as the current one.
            if (intLastPos >= MyStore.Length-1)
            {
                //create a new temporary array twice as big as the current one
                int[] intTemp = new int[MyStore.Length*2];

                //Now copy the entire old array to the new array
                Array.Copy(MyStore, intTemp, MyStore.Length);

                //Now assign our global variable for the data store to the new temporary array by pointing the Mystore reference
                //to the new array. This effectively makes the old array unreferenced, therefore marked for next round of Garbage
                //collection to recover the memory
                MyStore = intTemp;
            }
            //If the Array is not yet full, then add the new value to the index that follows the Lastposition. First increment the
            //value of Last position,that is the next index where we want to add the new value
            MyStore[++intLastPos] = Value; 
        }

        /// <summary>
        /// This method lists out the current content of the FlexiArray
        /// </summary>
        public void ShowContent()
        {
            //loop throug the array, but not through the whole array, as some of array can be empty. If we list out all elements
            //it becomes obvious that FlexiArray is indeed a predefined array, with some elements empty. Therefore, just list out
            //only as many items upto the intLastpos, which indicates last last filled position
            for(int i = 0; i <= intLastPos; i++)
            {
                Console.WriteLine("Postion {0} is: {1}",i,MyStore[i]);
            }

        }

        
    }
}

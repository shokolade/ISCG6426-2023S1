﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlexiArray
{
    /// <summary>
    /// We will use this class to test our classes and do our little experiments. This is not how unit testing is done, but
    /// this is a quick and dirty way to demostrate our little tests.
    /// </summary>
    internal class Test
    {
        /// <summary>
        /// Our first simple Hello Application showing how a message can be written to the console as some guidance for the 
        /// data entry user. Also how to run in a loop as many times as you want until a condition is met, such as the user
        /// typing the word 'exit'. Also note, the user is given the flexibility to type in any case, uppercase lowercase, proper
        /// case or any mixed-case. That's done converting the input .ToUpper() or .ToLower() and comapring the input in the
        /// given case.
        /// </summary>
        public void SayHello()
        {
            string strInput;
            Console.WriteLine("Please enter your name");
            Console.WriteLine("=======================");
            while ((strInput = Console.ReadLine()).ToUpper() != "EXIT")
            {
                //here we have used string concatanation to combine the string with the user input using plus sign. 
                //other examples will show a more readable string formatting method, passing arguments.
                Console.WriteLine("Hello World to you, " + strInput);
            }

        }
        
        /// <summary>
        /// This method demonstrates how we can declare an array of 100 ints and populate the array using 100 values using
        /// a loop. Instead of just assigning 1-100, we use a simple mathematical fomula by multiplying by 2 and adding 5 to it
        /// so that the values are not a series, and looks a bit like random, though it is not random. It is easy to see the 
        /// pattern. But we create another method further below to actually assign random numbers to an array.
        /// </summary>
        public static void MakeArrayAndShow()
        {
            int[] intMyArray = new int[100];
            for (int i = 0; i < intMyArray.Length; i++)
            {
                intMyArray[i] = (i * 2) + 5;
            }
            for (int i = 0; i < intMyArray.Length; i++)
            {
                Console.WriteLine("The value of element {0} is {1}.", i, intMyArray[i]);
            }
        }

        /// <summary>
        /// This test shows how an empty array is passed to fill with unordered random numbers, and print in ascending order
        /// of the index and in the reverse order. This is useful if we already have an Array of integers, that we need to
        /// fill with Random numbers
        /// </summary>
        public void ShowRandomArray()
        {
            //create an array of 20 elements
            int[] ThisArray = new int[20];

            //now use our 'CreateRandomArray' method in the utility class to fill a given array with random numbers
            ThisArray = Utility.CreateRandomArray(ThisArray,1,ThisArray.Length*5);

            //Now print the array filled with random numbers in the order of the index. ThisArray[0], ThisArray[1],...
            Utility.ShowThisIntArray(ThisArray);

            Console.WriteLine("Now reversing the print order of the array");
            Console.WriteLine("------------------------------------------");

            //Now test the utility method that prints an Array in the reverse order
            Utility.ShowThisIntArrayReverse(ThisArray);
        }

        /// <summary>
        /// This Test demonstrate the use of the CreateRandomArray(int) overloaded method, that is useful, when we want to 
        /// get a new Array created, filled with random unordered numbers and returned to us to dispaly in normal order and 
        /// in reverse order
        /// </summary>
        public void ShowRandomArrayOfAGivenSize()
        {
            int[] ThisArray = Utility.CreateRandomArray(10, 1,99);
            Utility.ShowThisIntArray(ThisArray);

            Console.WriteLine("Now reversing the print order of the array");
            Console.WriteLine("------------------------------------------");

            //Now test the utility method that prints an Array in the reverse order
            Utility.ShowThisIntArrayReverse(ThisArray);
        }
        
        /// <summary>
        /// This test shows the use of Utility method to generate an Array of a given size, and populate with random unique
        /// values in an ascending order.
        /// </summary>
        public void ShowRandomArrayOfUniqueSortedValues()
        {
            int[] ThisArray = Utility.CreateRandomSortedArray(25);
            Utility.ShowThisIntArray(ThisArray);

            Console.WriteLine("Now reversing the print order of the array");
            Console.WriteLine("------------------------------------------");

            //Now test the utility method that prints an Array in the reverse order
            Utility.ShowThisIntArrayReverse(ThisArray);
        }
        
        /// <summary>
        /// This is a Test method to try out filling a FlexiArray, by user inputting values one by one, demonstrating that it 
        /// is not going to run out of space.
        /// </summary>
        public void TestFlexyArrayWithUserInput()
        {
            //First print a message to the user to enter a value to add to FlexiArray or type Print to display content and 
            //end the program
            Console.WriteLine("Enter a Value to add or PRINT ");
            Console.WriteLine("-----------------------------");

            //remember that the input at the console is always read as a String, even if a user enters a number. That allows us
            //to keep adding numeric values and a string like 'Print' to end the program by printing.
            string strInput = Console.ReadLine();

            //Lets create an instance of our FlextArray
            FlexiArray fx=new FlexiArray();

            //First check the user's input is not the word "print' to end the program.Using .ToUpper() or .ToLower() we can make
            //the user's input case insensitive. Good to make input flexible,rather than having to type in proper case
            while (strInput.ToUpper() != "PRINT")
            {
                //you can use Convert.ToInt32(string) method to convert the input, but it will throw an exception if it can't
                //therefore, it is better to use TryParse method, which is safer, doesn't throw an excepton but returns 0 if it
                //can't convert successfully.
                //int a = Convert.ToInt32(strInput);

                //if the input is a number, try and convert it to a number representation without throwing an error
                int.TryParse(strInput, out int intInput);
                fx.Add(intInput);
                //keep on asking for an input, until user enters the work "print"
                strInput = Console.ReadLine();
            }
            //if the user has typed "Print" the execution exists the loop, so let's call the ShowContent() method of the FexiArray
            //class to list out all the values
            fx.ShowContent();

            //Console.ReadLine();
        }

        /// <summary>
        /// This test method fills a FlextArray with a given number of random numbers to demonstrate its dynamic nature of
        /// growth.
        /// </summary>
        public void TestFlexyArrayWithAutoGeneratedValues()
        {
            //First print a message to the user to enter a desired size of the random number
            //collection to create
            Console.WriteLine("How many random numbers you wish to generate to test the dynamic growth FlexiArray? ");
            Console.WriteLine("-----------------------------------------------------------------------------------");

            //remember that the input at the console is always read as a String, even if a user enters a number. That allows us
            //to keep adding numeric values and a string like 'Print' to end the program by printing.
            string strInput = Console.ReadLine();

            //Lets create an instance of our FlextArray
            FlexiArray fx;

            //First check the user's input is not the word "Exit' to end the program.Using .ToUpper() or .ToLower() we can make
            //the user's input case insensitive. Good to make input flexible,rather than having to type in proper case
            while (strInput.ToUpper() != "EXIT")
            {
                fx = new FlexiArray();
                //you can use Convert.ToInt32(string) method to convert the input, but it will throw an exception if it can't
                //therefore, it is better to use TryParse method, which is safer, doesn't throw an excepton but returns 0 if it
                //can't convert successfully.
                //int a = Convert.ToInt32(strInput);

                //if the input is a number, try and convert it to a number representation without throwing an error
                int.TryParse(strInput, out int intInput);
                int[] arrFeeder = Utility.CreateRandomArray(intInput, 1, intInput * 10);
                for (int i = 0; i < arrFeeder.Length; i++)
                {
                    fx.Add(arrFeeder[i]);
                }

                Console.Clear();
                //if the user has typed "Print" the execution exists the loop, so let's call the ShowContent() method of the FexiArray
                //class to list out all the values
                fx.ShowContent();

                Console.WriteLine("How many random numbers you wish to generate to test the dynamic growth FlexiArray? ");
                Console.WriteLine("-----------------------------------------------------------------------------------");

                //keep on asking for an input, until user enters the work "print"
                strInput = Console.ReadLine();
            }
        }

    }
}

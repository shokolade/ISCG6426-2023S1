﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlexiArray
{
    /// <summary>
    /// This Utility class contains a collection of useful methods that are usefull across all other classes
    /// </summary>
    internal static class Utility
    {
        /// <summary>
        /// This method fills a given array with random numbers and returns unsorted
        /// </summary>
        /// <param name="ThisArray">An empty integer array that needs to be filled with random numbers</param>
        /// <returns>Array filled with unsorted random numbers</returns>
        public static int[] CreateRandomArray(int[] ThisArray, int MinValue, int MaxValue)
        {
            Random ran = new Random();

            for (int i = 0; i < ThisArray.Length; i++)
            {
                ThisArray[i] = ran.Next(MinValue, MaxValue);
            }
            return ThisArray;
        }

        /// <summary>
        /// This method create an integer array of requested size, and fills with unorderd random numbers
        /// </summary>
        /// <param name="Size">Size of the Array wanted</param>
        /// <returns>An array of requested size, filled with unordered random numbers</returns>
        public static int[] CreateRandomArray(int Size, int MinValue, int MaxValue)
        {
            int[] ThisArray = new int[Size];
            Random ran = new Random();

            for (int i = 0; i < ThisArray.Length; i++)
            {
                ThisArray[i] = ran.Next(MinValue, MaxValue);
            }
            return ThisArray;
        }
        /// <summary>
        /// This Utility method creates an array of given size, and fill it with unique random values of ascending order. This
        /// Algorithm is efficient, as it creates unique values and also sorted order, without really having to sort it.
        /// </summary>
        /// <param name="Size">An integer of the required size of the array</param>
        /// <returns>An array filled with unique random numbers in an ascending order</returns>
        public static int[] CreateRandomSortedArray(int Size)
        {
            int[] ThisArray = new int[Size];
            Random rand = new Random();
            int intlast = 0;

            for (int i = 0; i < Size; i++)
            {
                intlast = ThisArray[i] = rand.Next(++intlast, intlast+8);
            }
            return ThisArray;
        }

        /// <summary>
        /// This is a small utility method, that takes any int array and displays the content on Console
        /// </summary>
        /// <param name="ThisArray">An Array of Integers</param>
        public static void ShowThisIntArray(int[] ThisArray)
        {
            for(int i = 0; i < ThisArray.Length; i++)
            {
                Console.WriteLine("Index {0}: {1}", i, ThisArray[i]);
            }

        }

        /// <summary>
        /// This is a small utility method, that takes any int array and displays the content on Console in reverse order
        /// </summary>
        /// <param name="ThisArray">An Array of Integers</param>
        public static void ShowThisIntArrayReverse(int[] ThisArray)
        {
            for (int i = ThisArray.Length - 1; i >= 0; i--)
            {
                Console.WriteLine("Index {0}: {1}", i, ThisArray[i]);
            }

        }
    }
}

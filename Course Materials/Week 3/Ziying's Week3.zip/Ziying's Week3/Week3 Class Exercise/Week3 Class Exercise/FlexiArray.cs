﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace Week3_Class_Exercise
{
    internal class FlexiArray
    {

        public static int[] Add(int[] arr, int numAppend)
        {
            int[] newArr = new int[arr.Length + 1];
            for (int i = 0; i < arr.Length; i++)
            {
                newArr[i] = arr[i];
            }
            newArr[arr.Length] = numAppend;
            return newArr;
        }
    }
}

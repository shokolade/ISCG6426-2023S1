﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week3_Class_Exercise
{
    internal class Format
    {
        public static void SeperatedFormat(int[] arr, int format = 0)
        {
            string punctuation;
            switch (format)
            {
                case 0:
                    punctuation = "{0}\n";
                    break;
                case 1:
                    punctuation = "{0}, ";
                    break;
                case 2:
                    punctuation = "({0}){1} ";
                    break;
                default:
                    punctuation = "{0}\n";
                    break;
            }
            for (int i = 0; i < arr.Length; i++)
            {
                if (format == 2)
                    Console.Write(punctuation, i, arr[i]);
                else
                    Console.Write(punctuation, arr[i]);
            }
            Console.WriteLine();
        }
    }
}

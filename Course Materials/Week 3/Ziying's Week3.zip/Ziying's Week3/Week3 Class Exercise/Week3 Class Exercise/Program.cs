﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week3_Class_Exercise
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //Implemnt a flexible array
            Console.WriteLine("-----Flexible Array-----");
            int[] array = { 3 , 5, 7, 9, 11, 13 };
            int[] array1 = FlexiArray.Add(array, 15);
            int[] array2 = FlexiArray.Add(array1, 17);
            int[] array3 = FlexiArray.Add(array2, 19);
            for(int i = 0; i < array3.Length; i++)
            {
                Console.WriteLine(array3[i]);
            }


            //Use four Search methods to search the index of value
            Console.WriteLine("-----Four Search Methods-----");
            int[] Array = { 1, 3, 5, 7, 9, 11, 13, 15, 17, 19 };
            int Value = 9;
            int Search1Index = Search.LinearSearch(Array, Value);
            int Search2Index= Search.BinarySearch(Array, Value);
            int Search3Index = Search.RecursiveLinearSearch(Array, 0, Value);
            int Search4Index = Search.RecursiveBinarySearch(Array, 10, 0, Value);
            Console.WriteLine("LinearSearch index: " + Search1Index);
            Console.WriteLine("BinarySearch index: " + Search2Index);
            Console.WriteLine("RecursiveLinearSearch index: " + Search3Index);
            Console.WriteLine("RecursiveBinarySearch index: " + Search4Index);

            //Use Random method to create a random array
            Console.WriteLine("-----RandomArr-----");
            int items = 10;
            int[] arr = RandomArr.CreateRandomSortedArray(items);
            for (int i = 0; i < arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }

            //Print array in different formats
            Console.WriteLine("-----Different Formatted Array-----");
            int[] arr1 = { 1, 3, 5, 7, 9, 11 };
            Format.SeperatedFormat(arr1, 1);
            Format.SeperatedFormat(arr1, 2);
        }
    }
}

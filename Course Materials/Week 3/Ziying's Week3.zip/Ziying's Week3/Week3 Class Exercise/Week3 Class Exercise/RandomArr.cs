﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week3_Class_Exercise
{
    internal class RandomArr
    {
        public static int[] CreateRandomArray(int items)
        {
            int[] arr = new int[items];
            Random r = new Random();
            for(int i = 0; i < items; i++)
            {
                arr[i] = r.Next();
            }
            return arr;
        }
        
        public static int[] CreateRandomSortedArray(int items)
        {
            int[] arr = new int[items];
            Random r = new Random();
            int Last = 0;

            for (int i = 0; i < items; i++)
            {
                Last = arr[i] = r.Next(++Last, Last + 10);
            }
            return arr;
        }
    }
}

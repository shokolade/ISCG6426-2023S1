﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Week3_Class_Exercise
{
    internal class Search
    {
        public static int LinearSearch(int[] ThisArray, int Value)
        {
            for (int i = 0; i < ThisArray.Length; i++)
            {
                if (ThisArray[i] == Value)
                {
                    return i;
                }
            }
            return -1;
        }
        public static int BinarySearch(int[] array, int Value)
        {
            int min = 0;
            int max = array.Length - 1;
            while (min <= max)
            {
                int mid = (min + max) / 2;
                if (Value == array[mid])
                {
                    return mid;
                }
                else if (Value < array[mid])
                {
                    max = mid - 1;
                }
                else
                {
                    min = mid + 1;
                }
            }
            return -1;
        }
        public static int RecursiveLinearSearch(int[] array, int index, int value)
        {
            if (index >= array.Length)
                return -1;
            if (array[index] == value)
                return index;
            return RecursiveLinearSearch(array, index + 1, value);
        }
        public static int RecursiveBinarySearch(int[] array, int high, int low, int value)
        {
            if (high >= low)
            {
                int mid = (high + low) / 2;
                if (array[mid] == value)
                    return mid;
                if (array[mid] > value)
                    return RecursiveBinarySearch(array, mid, low, value);
                return RecursiveBinarySearch(array, high, mid + 1, value);
            }
            return -1;
        }
    }
}

